from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Float, BigInteger, ForeignKey, DateTime
from sqlalchemy.sql import func
first_init_db = SQLAlchemy()
Column, Integer, String, Float, BigInteger, ForeignKey, DateTime = Column, Integer, String, Float, BigInteger, ForeignKey, DateTime
func=func

    