from ..extensions import first_init_db
from sqlalchemy import Column, Integer, ForeignKey, DateTime
from sqlalchemy.sql import func

db = first_init_db

class QuestionnaireUsersInterest(db.Model):
    __tablename__ = 'questionnaire_users_interest'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.user_id'))
    interests_id = Column(Integer) 
    created_at = Column(DateTime(timezone=True), server_default=func.current_timestamp())
    updated_at = Column(DateTime(timezone=True), server_default=func.current_timestamp(), server_onupdate=func.current_timestamp())

    def serialize(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'interests_id': self.interests_id,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S'),
        }
