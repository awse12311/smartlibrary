# models/questionnaire_books_interest.py
from ..extensions import first_init_db, Column, Integer, String, Float, BigInteger, ForeignKey, DateTime, func

db = first_init_db

class questionnaire_book_interest(first_init_db.Model):
    __tablename__ = 'questionnaire_books_interest'

    id = Column(Integer, primary_key=True)
    parent_interest_id = Column(Integer, ForeignKey('questionnaire_books_interest.id'))
    interest_name = Column(String(100), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def serialize(self):
        return {
            'id': self.id,
            'parent_interest_id': self.parent_interest_id,
            'interest_name': self.interest_name,
            'created_at': self.created_at,
            'updated_at': self.updated_at
        }